import {Composition,registerRoot} from 'remotion';
import {GrandPrix} from './input/src/gp/GrandPrix';
import type {RoundData} from './input/src/gp/race';
import originalData from './race.json';
import replayCamera from './replay-camera.json';
const data = {...originalData,replayCamera};
registerRoot(()=> <Composition id="Marbles-Race-4k" component={GrandPrix} fps={60} width={3840} height={2160} durationInFrames={16238} defaultProps={{id:'r13-jaipur',layout:'landscape',data:data as unknown as RoundData,audioId:'india-marbles-race-first-seed70-jaipur-fork-intake-v3-camera-c'}}/>);
